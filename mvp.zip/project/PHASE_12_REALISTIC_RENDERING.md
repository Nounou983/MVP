# Phase 12 — Realistic Rendering / Furniture Integration

## Goal
Make newly placed furniture look more physically integrated with the room photo without touching the mask/removal/RORem/LaMa pipeline.

## Added
- Automatic dominant-light estimation from the room photograph.
- Directional soft cast shadows per furniture item.
- Tight contact-occlusion shadows at the floor contact point.
- Conservative foreground luminance adaptation.
- Existing Phase 3E color matching and finishing remain active.
- Graceful fallback to the previous Phase 3E shadow renderer if the Phase 12 renderer is unavailable.

## Not changed
- Mask detection.
- AI removal / inpainting.
- RORem.
- LaMa.
- Reconstruction pipeline.
- Spatial Intelligence placement logic.

## UI
The final-render card now reports `Intégration réaliste — Lumière auto`.

## Verification
The new module is dependency-free and is loaded before `phase3e.js`.
