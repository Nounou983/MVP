# Phase 5.2.32 — Consumer Workspace + 3D Reliability Fix

## Goals
- Make the application feel like a consumer room-design product rather than a developer editor.
- Move furniture discovery into a visual bottom drawer inspired by the interaction pattern of modern room-planning apps.
- Make `Vue 3D` and `Ajouter un meuble 3D` resilient to delayed module loading.
- Keep GLB import as a true custom 3D object rather than silently assigning the model to a catalogue item.

## UI changes
- Slim left tool rail.
- Large room-first central workspace.
- Bottom furniture drawer with search, category filters and horizontal visual cards.
- Drag a furniture card onto the room to place it approximately at the drop position.
- Right inspector remains available for selected-object properties.
- Technical footer hints removed.

## 3D changes
- 3D boot is exposed through `window.Phase3Boot` and the UI waits for it before activating 3D actions.
- Removed the unnecessary `RoomEnvironment` addon dependency from the 3D module boot path.
- `Vue 3D` opens the free 3D view; Photo mode remains available.
- GLB import is owned by the main UI button and waits for the 3D module before opening the picker.
- Imported GLB files become dedicated custom objects.
- Imported model dimensions are estimated from the model bounding box.
- Catalogue 3D thumbnails are rendered after 3D initialization and retried shortly afterward to handle late-loaded catalogue DOM.

## AI/backend
No AI pipeline logic was intentionally changed in this UI/3D build. The existing backend remains the project's current backend.
