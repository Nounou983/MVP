# Phase 8.2 — AI Detection Repair

## Problem addressed

A single SAM/SegFormer selection could cover the visible body of a furniture item while missing thin or disconnected physical parts such as legs, feet, rails, arms, or lower edges. Those pixels remained in the photo after removal and became visible when new furniture was placed.

## Changes

- Added independent SAM probe passes around the selected object's semantic bounding box.
- Merges only small, high-confidence candidate components that overlap or physically touch the selected object.
- Keeps neighboring full-size furniture separate; automatic related-object grouping is now limited to near/contact components.
- Preserves the existing persistent multi-object selection workflow.
- Large-object removal no longer immediately returns HTTP 503 when RORem is unavailable/rejected: it uses a REMOVE-ONLY LaMa recovery pass and preserves the original image if reconstruction fails.
- `renderPreview()` uses `willReadFrequently` to remove the repeated Canvas2D readback warning.
- Local development disables optional analytics by default, preventing noisy `:8100/api/analytics/events` connection errors when the API service is not running. Production can enable analytics through `window.CIGOGNE_CONFIG`.

## Expected behavior

Clicking the main body of a bed, armchair, chest, sofa, etc. should now produce a more complete physical mask. The selection overlay should cover the object's thin structural parts without automatically swallowing a nearby unrelated piece of furniture.

For multiple objects, selections remain additive and are submitted as one union mask.
