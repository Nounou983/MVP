# Phase 9.1 — Reconstruction Non-Regression

## Why Phase 9.0 regressed

Phase 9.0 introduced a deterministic surface-guided candidate and allowed it to compete directly with RORem. On large furniture holes this candidate can be visually worse: surface classification and donor transfer are only estimates, and a large bed footprint can cross rug/floor/occlusion boundaries. The candidate can therefore produce blurred or smeared room texture.

## Fix

Phase 9.1 restores RORem as the primary large-object REMOVE-ONLY engine.

1. RORem multi-seed + residual refinement remains the quality anchor.
2. A low-risk seam harmonization pass is applied only as finishing; it cannot replace the interior reconstruction.
3. If RORem is unavailable or rejects all candidates, LaMa is used as an explicit large-object recovery instead of returning a 503 merely because a quality gate rejected RORem.
4. Surface-guided reconstruction is retained only as an emergency fallback and is never allowed to downgrade a successful RORem removal.
5. Pixels outside the confirmed mask remain protected.
6. No generative replacement furniture is enabled.

## Mask limitation

Phase 9.1 does not pretend to solve the upstream segmentation limitation. If the confirmed mask omits a bed leg or another disconnected physical component, no inpainting engine can remove pixels outside that mask. The next detection architecture should therefore move from semantic segmentation + click refinement toward instance-aware segmentation/object-level grouping with high-resolution mask refinement.
