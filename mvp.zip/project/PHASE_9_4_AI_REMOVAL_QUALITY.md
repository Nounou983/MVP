# Phase 9.4 — AI Furniture Removal Quality Repair

## Root cause found

The Phase 9.3 pipeline had three quality problems visible in the user's real logs:

1. **RORem was run with `guidance_scale=1.0`.** The official RORem inference guidance recommends classifier-free guidance and reports improved removal with content-irrelevant prompts. The previous build therefore disabled the guidance mechanism that the model's authors recommend for stronger removal.
2. **The internal RORem mask halos were too aggressive:** 18/24/30 px. With a high-quality SAM mask, those large halos caused broad low-frequency reconstruction and contributed to the observed `texture_ratio` values around 0.12–0.17.
3. **The deterministic surface reconstruction was effectively a last-resort path.** When RORem and LaMa both failed their visual gates, the selector still had no strong surface-first candidate in the normal decision path. This is wrong for interior-room removal: the hidden region is usually wall/floor/rug, not a new object that should be invented.

## Phase 9.4 changes

### RORem
- content-irrelevant prompt (`prompt=""`)
- CFG enabled at `guidance_scale=7.5`
- `strength=0.999`
- 40 diffusion steps
- internal dilation ensemble changed to `0 / 6 / 12 px`
- kept deterministic seeds
- kept the 512×512 native RORem working crop

### Candidate hierarchy

For large furniture:

1. RORem candidate that passes the visual removal gate
2. Surface-aware deterministic reconstruction candidate
3. Local LaMa recovery
4. If all gates fail, compare RORem + surface + LaMa using a stronger texture/structure-aware fallback score

The surface candidate is now a real candidate instead of an emergency-only path.

### Quality signals

The existing metrics remain in use:

- target change
- residual structure
- seam continuity
- furniture hallucination penalty
- texture ratio

The fallback now strongly penalizes low texture and incomplete target change so a blurry candidate cannot win merely because its semantic furniture penalty is lower.

## What is not changed

- Mask Engine V4 / SAM selection
- persistent multi-object selection
- frontend selection workflow
- 3D system
- furniture catalog
- rendering system
- API contract

## Validation

- `python -m compileall .` — passed
- complete server test suite — **69 passed**
- real RTX 3070 Ti RORem/LaMa inference — **not available in this environment**

The final visual score must therefore be confirmed by running the new ZIP on the user's real GPU with the same bedroom and living-room benchmark images.
