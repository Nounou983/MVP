# Phase 13 — Integration Reliability Repair

This build repairs the three visible integration paths without changing AI mask detection, AI removal, RORem, LaMa, or reconstruction.

## Phase 10 assistant
- Assistant-created objects now explicitly invoke the spatial solver even when the assistant supplies initial coordinates.
- Multiple repeated commands no longer intentionally stack at the exact same point when analysis is unavailable.
- Spatial relation metadata (front/left/right) is propagated into the solver.
- Success messages remain mutation-verified against the actual scene.

## Phase 11 spatial intelligence
- Removed a recursion path between `SpatialIntelligence.suggest()` and `Placement.suggestDrop()`.
- Solver now works before room analysis is available, using safe geometric priors and collision-aware candidate search.
- Denser candidate search separates repeated objects.

## Phase 12 rendering
- Realistic integration shadows are now visible in live Photo mode, not only in final export.
- Final export can render 2D catalogue furniture into a transparent foreground when 3D mode is not active.
- Legacy contact shadows are suppressed when Phase 12 is available to avoid double shadows.

## Deliberately untouched
Mask detection, AI removal, RORem, LaMa, and reconstruction remain unchanged.
