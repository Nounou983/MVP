# Phase 11 — Spatial Intelligence

## Goal
Improve the visible weakness in furniture placement without touching the AI-removal stack.

## Added
- Depth-aware apparent scale using the existing RoomModel camera projection.
- Floor-aware candidate search using the existing floor segmentation mask.
- Semantic placement priors:
  - sofas/beds/TV units near the detected wall;
  - coffee/dining tables in front of seating;
  - lamps beside seating;
  - chairs near tables;
  - rugs centered under seating;
  - plants beside seating.
- Candidate scoring penalizes off-floor placement, collisions, and detected openings.
- A visible **Placement intelligent / Optimiser la composition** control in the room panel.
- Existing manual placement remains supported; the optimizer is explicit for an existing composition.
- The 3D module automatically benefits from the improved perspective factor because it already consumes `App.getPerspectiveFactor()`.

## Deliberately not changed
Mask detection, AI removal, RORem, LaMa, and the reconstruction pipeline are untouched.
