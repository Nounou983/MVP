# Phase 10 — Smart Catalog + AI Interior Assistant

## Scope

This phase adds a consumer-facing product discovery layer and a natural-language catalogue assistant without changing the AI removal/reconstruction pipeline.

### Smart Catalog
- Natural-language-friendly product metadata (`styles`, `materialTokens`, `searchText`).
- Style, material and sorting controls.
- Real asset / 3D availability badges.
- Existing favorites, product details, variants, dimensions and placement metadata remain intact.

### AI Interior Assistant
The assistant is an explainable, offline intent engine over the real catalogue. It supports: 
- product discovery and recommendations;
- add one or multiple products;
- contextual placement such as `devant le canapé` and `de chaque côté du canapé`;
- replace the selected product;
- resize the selected product;
- move left/right/up/down;
- rotate by degrees;
- orient a selected object toward a TV/reference object;
- change finish/color when a matching catalogue variant exists.

A single command can add multiple objects as one editor history transaction.

## Non-regression
The existing AI removal modules were not modified. Backend test suite: 50 passed.
