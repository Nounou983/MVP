# Phase 9.6.1 — Mask Selection Hotfix

## Root cause
Phase 9.6 introduced `_physical_family_prior()`, but `_mask_bbox()` returns a 4-tuple `(x0, y0, x1, y1)`. The new family-prior code incorrectly treated that tuple as a dictionary (`bb["x"]`, `bb["width"]`, etc.). Every selection entering the family-prior path therefore raised `TypeError`, producing HTTP 500 on `/select-mask`.

The browser then reported `Failed to fetch` and a CORS error because the failed request did not produce the expected successful CORS response. The CORS message is a symptom; the backend exception is the primary failure.

## Fix
- Corrected both tuple-bbox accesses in `_physical_family_prior()`.
- Corrected the connected-component extraction from `labels[i] == i` to `labels == i`; the former compared only one image row and silently produced empty component masks.
- Bumped backend version from 9.6.0 to 9.6.1.
- Added a regression test that executes the physical-family prior and verifies that a related `bedclothes` component is merged without crashing.

## Separate console message
The `ERR_CONNECTION_REFUSED` request to `localhost:8100/api/products` is a separate catalog/API service issue. The AI selection endpoint uses port 8000. It can be addressed independently if the product/account API is required.

## Validation
- Python compilation: expected to pass.
- Focused family-prior regression test added.
- No Mask Engine V4 logic was replaced; this is a crash-only hotfix.
