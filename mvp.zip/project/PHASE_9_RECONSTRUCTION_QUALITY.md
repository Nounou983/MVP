# Phase 9 — Reconstruction Quality

## Why the mask problem remained

The Phase 8 selection pipeline has a structural limitation: the final reconstruction can only modify pixels that are inside the confirmed mask. If a bed leg, lower rail, chair foot, or another disconnected physical component is absent from the mask, no inpainting model can remove it later.

The observed misses are explained by a combination of:

1. **Semantic segmentation resolution** — SegFormer is used at a reduced analysis resolution, so thin furniture structures can disappear.
2. **ADE20K taxonomy** — a real bed is represented by several semantic concepts (bed/bedclothes/pillow/bench, etc.) and not necessarily as one complete physical object.
3. **Point/box ambiguity in SAM** — a click identifies the visible object region but does not guarantee that disconnected legs or occluded structures are included.
4. **Occlusion** — the mattress, bedding, bench and rug visually overlap; the model sees surfaces rather than the complete hidden 3-D object.
5. **Repeated resizing** — analysis masks are generated at reduced resolution and then restored to the photo size; small structures are particularly vulnerable to disappearing.
6. **Strict mask preservation** — the editor correctly refuses to alter pixels outside the confirmed mask. This protects neighboring furniture but also means missed pixels survive.

Phase 8.3 was therefore the last detection-focused iteration. Phase 9 changes the reconstruction strategy rather than pretending the detection issue is solved.

## Phase 9 pipeline

For large furniture, the backend now evaluates multiple REMOVE-ONLY candidates:

- **Surface-guided reconstruction:** estimates wall/floor/rug regions and reconstructs each surface independently.
- **RORem ensemble:** preserves the existing semantic removal model and its multi-seed refinement.
- **LaMa fallback:** used only when it provides a measurable improvement.
- **Contact-shadow cleanup:** a narrow lower-edge shadow region can be reconstructed with the surface, avoiding dark furniture ghosts.
- **Quality scoring:** candidates are compared against the original using seam continuity, furniture residuals, structural residuals and actual target change.
- **Strict compositing:** pixels outside the chosen reconstruction mask remain unchanged.

### Important limitation

Phase 9 improves the **quality of reconstruction inside the mask**. It does not claim to solve missing furniture pixels that were never selected. That remains a segmentation/detection problem and should be solved with a dedicated object-completion model rather than progressively inflating the mask.

## Validation

- Python compilation: passed
- JavaScript syntax checks: passed
- Backend suite: **50 passed**
- No new generative furniture replacement is enabled; Remove AI remains REMOVE-ONLY.
