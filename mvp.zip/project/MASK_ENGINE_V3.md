# Mask Engine V3

Mask Engine V3 is the segmentation-focused revision applied on top of the Phase 14 optimizer/stability baseline.

## Scope

This revision changes the **selection/mask engine only**. The Phase 14 RORem/LaMa optimizer and reconstruction quality-gate logic are intentionally left intact.

## Changes

1. **SegFormer misses no longer create a one-pixel SAM prior.**
   When ADE20K/SegFormer misses the click, V3 builds several real click-centered SAM boxes.

2. **SegFormer is soft evidence, not a hard clipping boundary.**
   SAM candidates can extend beyond the semantic component when their other evidence is strong.

3. **Multi-prompt SAM selection.**
   V3 evaluates point-only, contextual point, and point+box prompts at multiple local scales.

4. **Adaptive positive and negative prompts.**
   Positive points come from semantic interiors when available. Negative points are placed outside the semantic envelope/prompt box rather than at a fixed ring around the click.

5. **Disconnected physical-part recovery.**
   Nearby small SAM components can be retained/merged when geometry indicates they are part of the clicked object. This targets legs, feet, rails, arms, and similar structures.

6. **No blanket hole filling.**
   The final mask is not dilated or morphologically opened after selection. Holes and thin structures are preserved unless SAM itself did not predict them.

7. **Geometry-aware candidate ranking.**
   Candidates are scored using click inclusion, positive/negative prompt agreement, SAM IoU score, semantic overlap when available, prompt-box containment, and area plausibility.

8. **Evidence-based confidence.**
   `/select-mask` no longer returns the previous fixed 0.72–0.94 confidence range. The value is derived from actual mask geometry and click inclusion.

9. **Selection API version bumped to V3.**
   `/select-mask` returns `selection_version: 3` and reports `Mask Engine V3 (SAM + semantic context)`.

## Verification

CPU-only deterministic test suite:

- 63 tests passed
- `python -m py_compile server/main.py` passed

The real SAM/RORem/LaMa outputs were not available in the test environment. Therefore the changes are structurally tested, but final visual quality must still be validated on the user's RTX 3070 Ti with real room photographs.
