# Phase 9.3 — AI Furniture Deletion Quality Fix

## What was fixed

The SAM / Mask Engine V4 selection path is preserved. This phase changes the **AI deletion / reconstruction** path only.

### 1. Partial deletion was being selected as the final answer
The previous selector could prefer a RORem result with a lower SegFormer furniture penalty even when the target-change score showed that much of the selected furniture remained.

Phase 9.3 now prioritizes:
1. actual target change;
2. residual furniture-like structure;
3. boundary continuity;
4. local texture preservation;
5. SegFormer furniture penalty as a secondary signal.

### 2. RORem now uses an ensemble of tight configurations
Three configurations are evaluated with different crop context and mask dilation. This is intentional because RORem quality is sensitive to mask dilation, crop context and seed.

The final visible composite remains restricted to the confirmed SAM mask. Dilation is only an internal diffusion mask.

### 3. LaMa recovery is local instead of whole-room
When RORem does not clear the visual removal gate, LaMa now runs on an object-centred crop. This gives the inpainting model more pixels devoted to the selected furniture/background boundary and avoids diluting a large hole across the entire room.

### 4. Better fallback selection
If neither RORem nor LaMa passes every gate, the system no longer blindly prefers the candidate with the lowest furniture penalty. It compares the same removal-quality score and actual target-change evidence.

## Important

The mask-selection engine was intentionally left intact because the current Mask Engine V4 result is the accepted baseline.

This phase does **not** change the frontend selection UI or the duplicate-object naming behavior.

## Test status

- Python syntax check: passed
- Existing server test suite: **69 passed**
