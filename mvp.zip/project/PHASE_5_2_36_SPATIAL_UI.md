# Phase 5.2.36 — Spatial Consumer UI

Complete frontend rewrite around a full-screen room-first spatial architecture.

- 100vw/100vh room canvas behind all UI.
- Floating Apple-style glass controls.
- Minimal top navigation.
- Floating left tool rail.
- Contextual object menu above selected furniture.
- Floating translucent bottom furniture tray.
- Responsive mobile bottom-sheet behavior.
- Removed the unconditional yellow floor-profile overlay.
- Selection accents changed from gold to premium purple.
- Preserved the existing FastAPI, AI, editor and working 3D/GLB implementation.
- Kept the existing catalogue data and 3D thumbnail pipeline.
