# Phase 9.6 — Mask + Removal Quality Stabilization

## Why this phase exists

The real RTX 3070 Ti logs from Phase 9.5 show two coupled failure modes:

1. The selected mask can represent only a semantic fragment of a large piece of furniture. A bed click can start from `bedclothes`/partial geometry, while the removal stage then receives a mask that does not cover the complete physical object.
2. For large masks, all three original RORem configurations can fail simultaneously. The old pipeline then returns a known-bad LaMa/RORem fallback, which explains the observed stable low-quality result.

## Phase 9.6 changes

### Mask Engine V4.2

- Adds a conservative **physical-family prior** before SAM:
  - bed / bedclothes / pillow
  - sofa / seat / ottoman / pillow
  - chair / armchair / seat / stool
  - table / dining table / desk
  - cabinet / chest of drawers / wardrobe / bookcase
- Family components are accepted only when spatially attached/near the clicked component.
- The family prior is **not** used as a hard final mask. SAM still owns the final silhouette.
- Existing neighbour protection and disconnected physical-part recovery remain active.
- Diagnostics now expose family information and semantic-vs-family seed area ratios.

### RORem

- Keeps the existing tight candidates.
- Adds two wider-context candidates for large-object masks (`mask_ratio >= 5.5%`).
- Removes the long custom negative prompt. The inference remains content-irrelevant with CFG; quality is judged by the project's candidate gates instead of prompt adjectives such as `blurry` or `low detail`.

### Candidate fallback

When no RORem candidate passes the visual gate, the fallback now penalizes severe texture loss before target-change tie-breaking. This prevents a high-change but heavily smeared candidate from automatically winning.

## What is deliberately NOT changed

- No rewrite of the application.
- No replacement of SAM/V4 architecture with another segmentation model.
- No blanket mask dilation.
- No claim of visual improvement without a real GPU benchmark.

## Validation

CPU/static validation:

- `python -m compileall -q server` — passed.
- Existing focused removal/mask regression tests — **22 passed**.

Real validation still required on the RTX 3070 Ti with the same bedroom/living-room benchmark images.
