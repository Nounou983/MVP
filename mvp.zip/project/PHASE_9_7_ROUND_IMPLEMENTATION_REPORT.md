# La Cigogne D'Ailleurs — Phase 9.7 Controlled Fix Round

## Scope

This round implements only the three requested areas from the Phase 9.7 diagnostic:

- A — strict compositing invariant
- B — honest failure + removal quality-gate hardening + authoritative threshold/status handling
- C — related-object suggestions instead of silent auto-selection

No RORem seeds, SAM replacement, catalog, assistant, spatial intelligence, rendering, or auth/projects systems were changed.

## A — Strict compositing invariant

### Change
`server/main.py::_composite_inside_mask()` now:

1. normalizes the mask with NEAREST resampling,
2. thresholds it into a binary confirmed mask,
3. optionally feathers the binary mask,
4. clips the feather back to the original binary mask,
5. explicitly restores all pixels outside the binary mask from the source.

Therefore the invariant is exact:

```text
mask == 0  =>  output pixel == original pixel
```

`prepare_inpaint_mask()` documentation was corrected to state that it applies a small 1–4 px dilation. The dilation behavior itself was not changed.

### Before / after

The Phase 9.7 diagnostic recorded:

```text
BEFORE: maximum outside-mask RGB difference = 47/255
AFTER:  maximum outside-mask RGB difference = 0/255
```

The after result was also re-run directly after the edit.

Permanent regression test:

`server/tests/test_phase97_round.py::test_composite_preserves_every_pixel_outside_confirmed_binary_mask`

## B1 — Honest failure + gate semantics

### No silent failed final candidate

`hybrid_inpaint(..., allow_below_gate=False)` now returns a final image only when a candidate actually passes the authoritative removal gate.

If all candidates fail:

- normal mode: HTTP 422 is raised and the failed reconstruction is not returned;
- debug mode (`allow_below_gate=True`): the least-bad candidate is returned explicitly with:
  - `passed_gate: false`
  - `unconfirmed: true`
  - `quality_warning: true`

The previously dead `allow_below_gate` parameter is now actually consumed.

### Small-object path

The small-object LaMa path now runs the same `_candidate_passes_removal_gate()` semantics as the large-object path. It no longer unconditionally reports `passed_gate=True`.

### Tests

Permanent tests cover both normal failure and debug/unconfirmed behavior for large and small objects.

## B2 — Quality-gate hardening

### New signal: low-frequency surface consistency

Added `_surface_consistency_score()`.

It compares blurred LAB luminance/chroma statistics inside the reconstructed hole against the visible surrounding ring. This specifically addresses the proven failure mode where Laplacian variance can be high for a wrong dark/glossy hallucination.

Authoritative threshold:

```text
min_surface_consistency = 0.60
```

### Target-change redesign

The former blanket rule:

```text
change >= 0.34
```

was removed.

`target_change` is now only a near-no-op detector:

```text
noop_target_change = 0.02
```

So a correct reconstruction with change such as `0.163` is not rejected merely because it did not change 34% of target pixels. A result that changes effectively nothing (`< 0.02`) is still rejected.

### Synthetic adversarial evidence

The original Phase 9.7 diagnostic recorded this deliberately bad reconstruction:

```text
old total             = 5.45
old seam              = 0.351
old furniture penalty = 0.000
old target change     = 0.377
old residual          = 0.027
old texture ratio     = 2.084
old gate              = TRUE
```

On the new deterministic synthetic dark/glossy case, the new surface-consistency signal measured:

```text
surface consistency = 0.2514
required minimum    = 0.60
```

Replaying the original aggregate metrics through the new gate gives:

```text
new gate = FALSE
new score contribution from surface-consistency penalty ≈ +48.80
replayed total ≈ 54.25
```

The exact visual case in the real application still requires GPU/runtime validation; this CPU test verifies that the proven metric failure is no longer accepted by the gate.

### Low-change case

The diagnostic's old low-change case had:

```text
seam              = 5.24
furniture penalty = 0.000
change            = 0.163
residual          = 0.000
texture ratio     = 0.214
gate              = FALSE
```

The new gate no longer fails it because `change=0.163 < 0.34`; that blanket condition no longer exists. A detailed low-change synthetic reconstruction with:

```text
change            = 0.163
texture ratio     = 0.80
surface consistency = 0.95+
```

passes the new gate.

The old diagnostic example still has a texture-ratio failure (`0.214 < 0.35`), so it is not falsely declared good merely because the target-change rule was relaxed.

### Remaining limitation

This is a deterministic heuristic improvement, not a proof of human-level visual correctness. A determined adversarial image can still defeat hand-designed metrics. A future dedicated round can evaluate a learned/perceptual signal such as LPIPS, CLIP-style context similarity, or a VLM judge. None of those were introduced here.

## B3 — authoritative threshold source

All removal gate thresholds now live in:

```python
REMOVAL_GATE_THRESHOLDS
```

The actual enforcement code and `/inpaint-status` both consume that mapping.

The mapping includes final gate thresholds, no-op threshold, residual thresholds, and surface-partition/recovery thresholds.

The stale status values were removed.

`/inpaint-status` now reports:

```text
version = 9.7.0
phase   = 9.7
```

and exposes the same dictionary used by the enforcement code.

## C — related-object selection

`js/eraser.js::addRelated()` now treats SegFormer related components as suggestions.

The clicked primary object remains enabled.

Related components are added with:

```text
enabled = false
```

They therefore do not enter `unionMaskCanvas()` unless the user explicitly activates them.

The backend `_detect_related_furniture()` logic was not modified.

`node --check js/eraser.js` passes.

## Verification

### Full test suite

```text
81 passed in 10.28s
```

This is the original 74-test suite plus 7 new targeted regression tests.

### JavaScript syntax

```text
node --check js/eraser.js
PASS
```

### GPU/model verification

Not performed in this environment.

No claims are made here that SAM, SegFormer, RORem, or LaMa neural inference quality has visually improved on the user's RTX 3070 Ti. The changes were verified with deterministic CPU tests and static code inspection.

The next required real-runtime verification is the user's actual bedroom/bed test with the complete `/inpaint` terminal trace and the resulting image.

## Confirmed vs. still requiring runtime evidence

### Confirmed by execution

- outside-mask difference is exactly 0 after compositing fix;
- adversarial surface-consistency signal rejects the proven dark/glossy failure pattern;
- low-change detailed candidates are no longer rejected by the old 0.34 target-change floor;
- failed candidates are not returned in normal mode;
- debug mode explicitly marks failed candidates as unconfirmed;
- small and large paths share gate semantics;
- status thresholds equal the authoritative enforcement dictionary;
- all 81 tests pass;
- `eraser.js` passes Node syntax validation.

### Static-code verified

- related-object suggestions are disabled by default at insertion into the selection list;
- only enabled selections participate in the existing union-mask logic;
- no RORem seed/ensemble parameters were changed;
- the 512×512 RORem working-resolution limitation remains unchanged.

### Requires fresh RTX 3070 Ti runtime trace

- which neural backend produces the exact latest bedroom screenshot;
- whether the new surface-consistency gate improves that real image;
- real SAM/SegFormer boundary quality;
- real RORem/LaMa generation quality;
- visual IKEA-Kreativ-level removal quality.
