# La Cigogne D'Ailleurs — Phase 9.7 Round 2 Runtime/Code Diagnostic

## Executive finding

The supplied RTX runtime log shows:

- selected RORem seed: **11037**
- final `furniture_penalty`: **0.6770** in the final recheck (0.6774 in the selected-candidate line)
- `passed_gate=True`
- HTTP 200
- screenshot: visibly ghosted/partially reconstructed result

The exact current source explains the gate result. In the uploaded ZIP, `server/main.py` defines the authoritative threshold as:

```python
REMOVAL_GATE_THRESHOLDS["max_furniture_penalty"] = 0.70
```

at the original ZIP's `server/main.py` line 34. `_candidate_passes_removal_gate()` compares `fp <= t["max_furniture_penalty"]` at line 1881. Therefore **0.6774 <= 0.70 was expected to pass**. This is a gate-calibration problem, not a stale-status wiring problem and not a B1 failure.

This round tightens the authoritative ceiling to **0.60**. The exact real runtime value 0.6774 is now rejected by the same gate function.

A second, separate compositing issue was also verified statically/executionally: the previous outside-mask fix made alpha exactly zero outside the binary mask, but the Gaussian feather still produced alpha values below 1.0 inside the confirmed mask. On the synthetic geometry, the old implementation had **504/2000 inside pixels with alpha < 1**, minimum alpha **0.5615**. That can produce translucent/ghosted furniture at the mask boundary. The round-2 ZIP removes this internal transparency: inside the confirmed mask the generated candidate is now copied at full opacity; outside remains byte-for-byte original.

## Source-of-truth ZIP inspected

Uploaded ZIP SHA-256:

`138e7b131de422bbe6fdc8b99310d5aaac1e05d1b9b207a6e00a6d9fd579526f`

No bedroom source image, exact submitted mask PNG, raw seed=11037 RORem output, or final runtime output image was present inside that ZIP. Consequently the artifact-boundary steps that require those exact files cannot honestly be claimed as executed here.

## 1. Exact furniture-penalty root cause

### Original ZIP

- `server/main.py:32-55`: `REMOVAL_GATE_THRESHOLDS`
- original line 34: `max_furniture_penalty = 0.70`
- original `server/main.py:1870-1885`: `_candidate_passes_removal_gate()`
- original line 1881: `fp <= t["max_furniture_penalty"]`

Thus:

`0.6774 <= 0.70` -> **PASS**.

### Round-2 change

- current line 34: `max_furniture_penalty = 0.60`
- same gate line now evaluates `0.6774 <= 0.60` -> **FAIL**.

0.60 is a deliberately conservative ceiling, not a statistically calibrated optimum. It is grounded in the real failure value: it places a clear margin below 0.6774 while leaving the already-used low-penalty candidates unaffected. The synthetic glossy-blob failure is not solved by this threshold alone because that adversarial case had `furniture_penalty=0.000`; it remains protected by the surface-consistency guard.

## 2. B1 status: present, not lost/reverted

B1 is present in the supplied ZIP.

`server/main.py:3253-3260` documents and implements `allow_below_gate`.
`server/main.py:3272-3292` implements `_unconfirmed_or_raise()`:

- normal mode (`allow_below_gate=False`) -> HTTP 422 when no candidate passes;
- debug mode -> returns the best rejected candidate with:
  - `passed_gate=False`
  - `unconfirmed=True`
  - `quality_warning=True`.

The large-object path rechecks RORem at `server/main.py:3330-3345` and only returns normally if `_candidate_passes_removal_gate()` is true. Failed RORem candidates are appended for recovery rather than returned as successful results.

The small-object path at `server/main.py:3424-3446` also uses `_candidate_passes_removal_gate()` and the same explicit failure policy.

Therefore the reported 0.6774 pass is **not B1 failing**. It passed because the authoritative furniture threshold was too permissive.

## 3. B3 status: present and authoritative

B3 is also present in the supplied ZIP.

`REMOVAL_GATE_THRESHOLDS` is the single mapping at `server/main.py:32-55`.
The enforcement path imports/reads this mapping directly (`server/main.py:1872`, `1880-1884`).
`/inpaint-status` reads the same mapping at `server/main.py:3462-3471`.

Current status output reports:

- `phase = 9.7`
- `version = 9.7.0`
- `max_furniture_penalty = 0.60`

So the status endpoint is not stale for this threshold. The previous stale-status pattern was structurally removed; the remaining defect was simply that the shared authoritative value itself was too loose.

## 4. Artifact-boundary trace — exact requested order

### Step 1 — exact binary mask submitted to `/inpaint`

**BLOCKED for the exact bedroom case.** The supplied ZIP contains source code/tests but not the runtime mask PNG from the user's RTX run. The conversation screenshots are not a filesystem artifact and cannot provide exact dimensions, connected components, or byte-level comparison.

The source path is confirmed: `eraser.js:243-246` creates the union canvas, converts it to PNG, and posts it as the `mask` form field to `/inpaint`.

`eraser.js:94-114` confirms only `item.enabled` selections participate in the union mask.

### Step 2 — raw RORem seed=11037 output before compositing

**BLOCKED for the exact bedroom case.** The uploaded ZIP has no raw RORem output image and this CPU environment has no NVIDIA runtime (`nvidia-smi` unavailable). The user's terminal log proves the model ran on their RTX machine, but it does not contain the raw image artifact.

### Step 3 — final post-composite image using the same mask

**BLOCKED as an artifact operation.** The supplied screenshot is evidence of the visual symptom but is not the saved post-composite pixel artifact required for a reproducible comparison.

### Step 4 — raw RORem vs final, region-by-region

**NOT PROVABLE from the supplied artifacts.** The source shows a downstream compositing stage, but without the raw seed=11037 image and exact final image, the relative contribution of RORem versus compositing cannot be measured on the real bedroom case.

### Step 5 — outside-mask invariant on the real pair

**BLOCKED for the real pair** because the exact pair is absent.

The permanent synthetic invariant test executes and returns maximum outside-mask difference **0**.

### Step 6 — B2 adversarial synthetic tests

Executed on the current code.

#### Glossy blob

Historical pre-B2 diagnostic:

| metric | historical value |
|---|---:|
| total | 5.45 |
| seam | 0.351 |
| furniture_penalty | 0.000 |
| target_change | 0.377 |
| residual_structure | 0.027 |
| texture_ratio | 2.084 |
| old gate | TRUE |

Current deterministic synthetic surface check:

- surface consistency = **0.251401**
- required minimum = **0.60**
- current gate = **FALSE**

This remains rejected before and after the new 0.60 furniture ceiling because its furniture penalty is 0.000. Therefore the new ceiling is not being falsely credited with solving the glossy-blob adversarial case.

#### Reasonable low-change reconstruction

- target_change = **0.163**
- texture_ratio = **0.80**
- surface_consistency = **0.95**
- seam = **5.24**
- furniture_penalty = **0.0**
- residual = **0.0**

Current gate = **TRUE**. This confirms the old blanket `target_change >= 0.34` floor is gone.

### Step 7 — synthetic real-case furniture penalty 0.6774

Executed.

| authoritative ceiling | `fp=0.6774` |
|---:|---|
| 0.70 (supplied ZIP) | PASS |
| 0.60 (round-2 ZIP) | **FAIL** |

A dedicated test forces the exact metrics from the user's runtime case through `_candidate_passes_removal_gate()` and confirms rejection. A second test exercises `hybrid_inpaint()`:

- normal mode -> HTTP 422
- debug mode -> image returned only as `unconfirmed=True`, `passed_gate=False`, `quality_warning=True`.

### Step 8 — small-object gate semantics

Executed. A small-object LaMa path no longer hardcodes `passed_gate=True`. It evaluates the same `_candidate_passes_removal_gate()` function and follows the same normal/debug failure semantics.

### Step 9 — `/inpaint-status` threshold comparison

Executed by calling the endpoint function directly in the test environment.

The returned `quality_gate` dictionary is exactly `REMOVAL_GATE_THRESHOLDS`.
No mismatch was found.

The current returned values include:

- `max_seam = 55.0`
- `max_furniture_penalty = 0.60`
- `max_residual_structure = 0.45`
- `min_texture_ratio = 0.35`
- `min_surface_consistency = 0.60`
- `noop_target_change = 0.02`
- surface-partition/recovery thresholds remain separately defined in the same authoritative mapping.

### Step 10 — C contract / network boundary

Static source verification confirms the contract:

- clicked primary selection: `enabled=true` (`eraser.js:120-128`);
- related SegFormer candidates are inserted with `enabled=false` (`eraser.js:131-142`);
- union mask skips all disabled entries (`eraser.js:101-105`);
- `/inpaint` receives the resulting union PNG (`eraser.js:243-246`).

The client currently uses a `selectionKey(label,bbox)` rather than a dedicated object ID. No exact client-side runtime log for the user's bed+armchair case was supplied, so the exact network payload for that run cannot be claimed as observed.

The screenshot showing the second Bed unchecked is consistent with the source contract, but it is not sufficient by itself to prove the actual uploaded PNG.

## 5. Compositing diagnosis

This is a **new partial-opacity-inside-the-mask issue**, distinct from the previous outside-mask leakage bug.

### Previous fix that remains correct

`_composite_inside_mask()` still guarantees:

`mask == 0 -> output == original`

The permanent synthetic test gives outside difference **0**.

### Newly verified issue in the supplied ZIP

The supplied implementation blurred the binary mask with Gaussian sigma 0.8 and then multiplied by the binary mask. That correctly clipped alpha to zero outside, but it did not force alpha to one inside.

On the exact synthetic 40x50 mask used for the regression test:

- inside pixels = **2000**
- inside pixels with alpha < 1 = **504**
- minimum inside alpha = **0.5615**
- maximum inside alpha = **1.0000**
- outside maximum alpha = **0.0000**

Thus the previous fix was incomplete for the new symptom: it solved external leakage but retained internal transparency.

### Round-2 fix

The composite now uses the confirmed binary mask as a strict ownership mask:

- outside -> original, byte-for-byte;
- inside -> generated candidate at full opacity.

Boundary harmonization remains upstream in `_phase9_edge_harmonize()`.

After the fix:

- outside max difference = **0**;
- every inside pixel equals the generated candidate exactly;
- effective alpha inside = **1.0 everywhere**.

## 6. Verification matrix

| Area | Status | Evidence |
|---|---|---|
| Furniture penalty 0.6774 rejection | **VERIFIED** | Dedicated regression test; exact runtime metrics replayed |
| B1 honest failure | **VERIFIED** | Existing + new unit tests; source path at hybrid_inpaint |
| B1 debug escape hatch | **VERIFIED** | Dedicated 0.6774 debug test |
| B3 authoritative threshold source | **VERIFIED** | Status test equals mapping |
| B2 glossy blob | **VERIFIED as rejected** | surface consistency 0.251401 < 0.60 |
| B2 low-change case | **VERIFIED** | change 0.163 passes with strong other signals |
| Small-object gate semantics | **VERIFIED** | permanent test |
| Outside-mask compositing invariant | **VERIFIED** | max difference 0 |
| Inside-mask full opacity | **VERIFIED** | generated pixels copied exactly |
| Related-object suggestion behavior | **STATICALLY VERIFIED** | `enabled=false` for related items; disabled items omitted from union |
| Exact bedroom mask artifact | **NOT VERIFIED** | runtime mask PNG not supplied |
| Raw RORem seed=11037 artifact | **NOT VERIFIED** | raw output not supplied; no NVIDIA runtime here |
| Real raw-vs-final pixel comparison | **NOT VERIFIED** | required artifacts absent |
| Real RTX neural quality | **NOT VERIFIED** | this environment has no NVIDIA runtime |

## 7. Test execution

Current round-2 ZIP after the changes:

```text
83 passed in 10.32s
node --check js/eraser.js -> PASS
```

The supplied ZIP started with **81 passing tests**. Two targeted tests were added:

1. exact real-case furniture penalty 0.6774 must be rejected;
2. exact real-case furniture penalty 0.6774 must remain explicitly unconfirmed in debug mode.

The existing compositing regression was strengthened to assert full-opacity inside the confirmed mask in addition to the existing outside-mask invariant.

## 8. Remaining RTX 3070 Ti checks required from the user

The next runtime trace must save these exact artifacts from the same bedroom operation:

1. the exact PNG mask uploaded to `/inpaint`;
2. raw RORem seed=11037 output before `_phase9_edge_harmonize()` and `_composite_inside_mask()`;
3. the final image returned by `/inpaint`;
4. `/inpaint` JSON metadata, including `quality_gate_passed`, `unconfirmed`, `backend`, `furniture_penalty`, and the other metrics;
5. `/inpaint-status` JSON from the same running build;
6. browser console/network evidence showing the selected `selectionKey`s and the uploaded union-mask dimensions/connected components.

The critical expected change after this ZIP is that a real RORem candidate with `furniture_penalty≈0.6774` must **not** be returned as a normal successful pass. In normal mode it must be rejected and recovery must continue; if all recovery candidates fail, normal mode must fail rather than return the ghost. Debug mode may expose the best failed candidate, but must mark it `unconfirmed`.

The 512x512 RORem working-resolution limitation remains intentionally out of scope.
