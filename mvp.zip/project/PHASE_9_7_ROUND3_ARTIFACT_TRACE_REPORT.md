# La Cigogne D'Ailleurs — Phase 9.7 Round 3 Artifact Trace

## Executive status

### What the supplied RTX log proves

The current supplied RTX trace is a **single-bed** removal trace, not a bed+armchair trace:
`[Phase 9.1] mask=12.26% bbox=(578,353)-(1172,736) size=(1408,768)`.

It proves B1 is working on a real GPU run:

- RORem selected seed=2026 and failed the gate: `furniture_penalty=0.7289`, `texture_ratio=0.15`.
- Phase 9.4 surface candidate failed its gate.
- Phase 9.7 surface ensemble was rejected: `accepted=1 substantial=2`.
- LaMa recovery had `furniture_penalty=0.0893`, but `seam=59.78` and `texture_ratio=0.23`, so `passed_gate=False`.
- The pipeline logged `Phase9.7 UNCONFIRMED candidate=lama`.
- `/inpaint` returned **HTTP 422 Unprocessable Entity**.

That is the expected honest-failure behavior. B1 does not need to be re-litigated.

This round therefore focuses on the missing artifact boundary, the reusable trace tooling, the current B2 numbers, and the frontend handling of 422.

---

## 1. Step 1 — exact submitted mask

The exact PNG uploaded by the browser was **not captured** in the supplied runtime artifacts.

The RTX log does provide exact mask metadata for the current single-bed run:

- dimensions: **1408 × 768**
- area ratio: **12.26%**
- bbox: **(578,353)–(1172,736)**
- approximate foreground area: **72,? pixels** (the log gives the ratio, not the binary pixel count)

The requested bed+armchair screenshot from the conversation is available as a UI screenshot, so the reusable diagnostic tool also generated a **closest UI-preview approximation** from that screenshot. It is explicitly not claimed to be the network payload.

`diagnostics/phase97_round3_artifact_trace/mask_submitted.png`:
- 1408 × 768
- area ratio: **0.108330**
- foreground pixels: **117,142**
- bbox: **[67,315,1171,735]**
- connected components after removing tiny preview-noise components: **7**
- source: **approximate UI preview**

The large components visually correspond to the bed and armchair. The remaining small fragments show why a screenshot cannot be used as a byte-exact network mask.

---

## 2. Step 2 — raw RORem outputs

The exact raw neural outputs were not captured:

- `rorem_raw_seed2026.png` — **NOT CAPTURED**
- `rorem_raw_seed11037.png` — **NOT CAPTURED**
- `lama_raw.png` — **NOT CAPTURED**

The bundle contains watermarked placeholders for these names so the six-file diagnostic contract is explicit. They are not represented as model outputs.

The local environment has no NVIDIA runtime, so these cannot be regenerated here.

---

## 3. Step 3 — final composite

`composited_final.png` is a screenshot-derived runtime artifact preserved for visual reference.

It shows the same broad, low-detail/ghosted reconstruction symptom visible in the supplied runtime screenshots. It is not a byte-for-byte `/inpaint` response capture.

---

## 4. Step 4 — raw vs final

**Not measurable yet.**

The required pixel-region comparison is only valid when all four exact artifacts are present:

1. exact original,
2. exact binary mask,
3. raw RORem/LaMa output for the same candidate,
4. exact final output.

The diagnostic script deliberately refuses to infer a raw neural image from a final screenshot.

### Why this matters

The current source code's compositor is now deterministic:

- outside confirmed mask → original pixel exactly;
- inside confirmed mask → generated candidate exactly.

So if the fresh RTX artifact pair shows that raw RORem is already ghosted, the bottleneck is upstream generation/gating. If raw RORem is strong and final becomes ghosted, that would be a new downstream problem. The missing raw/final pair is the evidence needed to distinguish those cases.

---

## 5. Step 5 — compositing invariants

The permanent synthetic regression was executed on the current code:

- maximum outside-mask RGB difference: **0**
- inside-mask output exactly equals generated candidate: **TRUE**
- effective alpha inside: **1.0 everywhere**
- effective alpha outside: **0.0 everywhere**

Therefore the previous two compositing defects are not present in the current implementation:

1. outside-mask Gaussian alpha leakage — fixed;
2. partial opacity inside the confirmed mask — fixed.

The exact real-bedroom pair still needs an RTX artifact capture to verify the invariant on production pixels.

---

## 6. Step 6 — B2 adversarial tests

### Glossy blob

Historical adversarial aggregate:

| metric | old value |
|---|---:|
| total | 5.45 |
| seam | 0.351 |
| furniture penalty | 0.000 |
| target change | 0.377 |
| residual structure | 0.027 |
| texture ratio | 2.084 |
| old gate | TRUE |

Current surface-consistency check:

- surface consistency = **0.251401**
- minimum required = **0.60**
- current gate = **FALSE**

This is a real before/after gate change, and it is not caused by the furniture threshold because `furniture_penalty=0.000`.

### Reasonable low-change case

- target change = **0.163**
- texture ratio = **0.80**
- surface consistency = **0.95**
- seam = **5.24**
- furniture penalty = **0**
- residual = **0**

Old gate with the former `target_change >= 0.34` blanket minimum:
**FALSE**.

Current gate:
**TRUE**.

So the old low-change false rejection is fixed.

### Real runtime furniture-penalty replay

The earlier real-case aggregate:

`seam=16.68, fp=0.6774, change=0.212, residual=0, texture=0.58, surface=0.933`

gives:

- old ceiling `0.70` → **PASS**
- current ceiling `0.60` → **FAIL**

This is the exact regression that caused the previous ghost to be served.

---

## 7. Current RTX log — texture-ratio / busy-room hypothesis

The current single-bed RTX trace is unusually consistent:

### RORem

| seed | inside variance | outside variance | texture ratio |
|---|---:|---:|---:|
| 2026 | 206.2 | 1372.8 | **0.150** |
| 7319 | 177.5 | 1372.8 | **0.129** |
| 11037 | 170.4 | 1372.8 | **0.124** |
| 17041 | 196.5 | 1372.8 | **0.143** |
| 24019 | 162.9 | 1372.8 | **0.119** |

### Phase 9.7 surface partitions

- rug: **0.05**
- floor: **0.11**

### LaMa recovery

- overall LaMa: **0.23**
- rug LaMa: **0.33**
- floor LaMa: **0.35**

The fixed final-gate floor is `0.35`.

### Interpretation

This strongly demonstrates that the **current metric makes this room extremely difficult to pass**: every RORem candidate is far below 0.35, the rug partition is 0.05, the floor partition is 0.11, and overall LaMa is 0.23.

However, it does **not yet prove why**.

The missing raw images prevent a visual determination of whether:
- every candidate is genuinely too flat/blurry, or
- the surrounding room has such high texture variance (1372.8 in the RORem context) that a fixed 0.35 ratio is intrinsically too aggressive.

A learned/perceptual signal or a room-adaptive texture baseline may be worth a dedicated future round, but this round does not implement that redesign.

---

## 8. Step 7 — furniture_penalty=0.677 test

The permanent regression test forces:

`fp=0.6774`

through the current authoritative gate.

Result:

- old 0.70 ceiling → **PASS**
- current 0.60 ceiling → **FAIL**

The existing debug-path regression also confirms:

- normal mode → **HTTP 422**
- debug mode → returns only an explicitly `unconfirmed=true`, `passed_gate=false`, `quality_warning=true` candidate.

---

## 9. Step 8 — small-object semantics

The current test suite exercises a small-object LaMa path.

It uses the same `_candidate_passes_removal_gate()` function as the large-object path, and failure follows the same normal/debug semantics.

Thus `passed_gate` now has one meaning: a candidate has actually passed the authoritative visual gate.

---

## 10. Step 9 — `/inpaint-status`

`REMOVAL_GATE_THRESHOLDS` is the single mapping consumed by:

- `_candidate_passes_removal_gate()`
- `/inpaint-status`

Current authoritative values include:

- max seam: **55.0**
- max furniture penalty: **0.60**
- max residual structure: **0.45**
- min texture ratio: **0.35**
- min surface consistency: **0.60**
- no-op target change: **0.02**

`/inpaint-status` reports the same mapping and:
- phase **9.7**
- version **9.7.0**

No status/enforcement mismatch was found.

---

## 11. Step 10 — related-object selection / network boundary

The current source contract is correct:

- the clicked primary selection is enabled;
- related SegFormer suggestions are inserted with `enabled=false`;
- `unionMaskCanvas()` skips disabled selections;
- the resulting union PNG is the file sent to `/inpaint`.

This is verified by static source inspection and the current `eraser.js` implementation.

A browser network capture for the exact run was not supplied, so the exact object IDs and exact uploaded PNG component count cannot be claimed as runtime-observed.

---

## 12. Frontend handling of HTTP 422

### Before this round

`eraser.js` surfaced the server's raw failure detail through the generic catch path.

### Changed now

For `/inpaint` HTTP 422:

- the response is recognized explicitly;
- if a future response includes `unconfirmed=true`, the UI reports that the result is not safe to apply;
- otherwise the user gets:

> **Aucun candidat n’a satisfait le contrôle qualité. Essayez un autre objet ou une photo plus nette.**

No blank state and no raw `HTTP 422` message is shown to the user.

Normal success handling remains unchanged.

`node --check js/eraser.js` passes.

---

## 13. Reusable diagnostic tool

Added:

`server/tools/phase97_artifact_trace.py`

It accepts exact runtime artifacts and produces:

- `mask_submitted.png`
- `alpha_map.png`
- `rorem_raw_seed2026.png`
- `rorem_raw_seed11037.png`
- `lama_raw.png`
- `composited_final.png`
- `trace_summary.json`

It also computes:
- mask dimensions/area/bbox/components;
- outside-mask difference;
- inside-mask difference versus generated output;
- exact raw-vs-final comparison when all required files exist.

It never fabricates a missing neural artifact.

---

## 14. Verification

Executed locally on the current modified bundle:

```text
pytest -q server/tests test
83 passed in 10.87s

node --check js/eraser.js
PASS

python -m py_compile server/tools/phase97_artifact_trace.py
PASS
```

GPU availability:

```text
nvidia-smi
→ unavailable

PyTorch CUDA
→ unavailable in this environment
```

Therefore these remain RTX-only:
- exact browser-uploaded mask,
- raw RORem seed=2026 and seed=11037,
- raw LaMa output,
- exact final response pixels,
- raw-vs-final comparison,
- real alpha invariant on that exact pair,
- exact browser/network object IDs and uploaded mask components.

---

## 15. Scope preserved

Not changed:
- RORem seeds/ensemble parameters
- SAM replacement
- 512×512 RORem working-resolution architecture
- catalog
- AI assistant
- spatial intelligence
- rendering
- auth/projects

The only product-code change this round is user-facing HTTP 422 handling in `js/eraser.js`; the other additions are diagnostics/tests/reporting.

