# Phase 5.2.30 — Consumer UX / Furniture Visuals

This build continues Phase 5.2.29 and focuses on making the editor understandable to a non-technical client.

## What changed

- Removed the visible Three.js XYZ TransformControls (red/green/blue arrows).
- 3D furniture is now manipulated directly: select a piece and drag it on the room photo.
- Added a floating, plain-language action bar beside the selected furniture:
  - Déplacer
  - Tourner
  - Plus petit
  - Plus grand
  - Supprimer
- Replaced technical wording in the 3D inspector with consumer wording.
- Renamed the 3D view actions to `Sur la photo` and `Vue 3D`.
- Replaced the catalogue's flat SVG furniture symbols with rendered 3D thumbnails generated from the same furniture geometry used by the 3D scene.
- Removed developer-style keyboard/mouse instructions from the bottom status area.
- Kept the existing AI, room analysis, 2D editor, GLB loading, rendering and export functionality.

## UX principle

A client should not need to understand coordinates, XYZ axes, gizmos, transforms, meshes, or rendering terminology. The scene itself is the primary interaction surface.
