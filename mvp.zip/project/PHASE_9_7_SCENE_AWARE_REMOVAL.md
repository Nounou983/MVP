# Phase 9.7 — Scene-Aware Object Removal

## Objective

Turn object selection and AI removal into one pipeline by decomposing a confirmed furniture mask into the room surfaces hidden behind it.

## What changed

- **Mask Engine V4.2 remains the silhouette authority.** SegFormer supplies semantic/physical-family context and negative neighbour evidence; SAM supplies the final object boundary.
- Added a **Scene Layer Map** for the confirmed mask:
  - `1 = floor`
  - `2 = wall`
  - `3 = rug/carpet`
  - `0 = unknown`
- Added **surface partitioning** so one bed/desk/sofa mask can become separate wall/floor/rug reconstruction regions.
- Added a **surface-aware RORem ensemble**:
  - wall: wider contextual reconstruction
  - rug: texture-preserving reconstruction
  - floor: perspective/floor-context reconstruction
  - unknown: conservative fallback
- Each surface partition is quality-gated independently. Failed partitions may use local LaMa recovery.
- Accepted surface candidates are composited **only inside the confirmed object mask**; untouched pixels remain unchanged.
- The complete surface-aware result is then evaluated with the existing removal metrics: seam, furniture penalty, target change, residual structure, and texture ratio.
- A rejected surface-aware candidate remains available in the final fallback comparison rather than being discarded.

## Why this architecture exists

A large furniture mask can hide different physical surfaces. A single RORem/LaMa pass must otherwise solve wall, rug, and floor reconstruction as one homogeneous hole. Phase 9.7 instead converts the problem into several constrained reconstruction tasks and then recombines them.

## Validation

- `python -m py_compile server/main.py` — passed.
- Regression suite: **20 passed**.
- GPU model inference was not executed in this build environment; real-image quality must be validated on the user's CUDA machine.

## Runtime diagnostics

Look for:

```text
Phase9.7 surface=wall ...
Phase9.7 surface=rug ...
Phase9.7 surface=floor ...
Phase9.7 surface ensemble selected: ...
```

These lines expose which background surfaces were detected and whether each reconstruction partition passed its local quality checks.
