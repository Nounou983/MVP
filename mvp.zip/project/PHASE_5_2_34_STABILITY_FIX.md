# Phase 5.2.34 — 3D Stability + Consumer UI Polish

- Fixed the `THREE.Scene` startup crash by using explicit top-level dynamic imports for Three.js, GLTFLoader and OrbitControls.
- Phase3Boot now waits for the complete 3D dependency graph before enabling the UI.
- Updated cache-buster to build=534.
- Kept GLB import through GLTFLoader and custom furniture handling.
- Removed the broad translucent stage header that visually covered the room.
- Reduced the furniture drawer so it remains useful without dominating the room image.
- No `eval`, `new Function`, or string-based timers were added.
