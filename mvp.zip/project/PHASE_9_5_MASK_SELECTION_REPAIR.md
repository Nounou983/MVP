# Phase 9.5 — Mask Engine V4.1 Neighbour-Protected Selection

## Problem addressed

Real living-room tests showed that the removal engine could receive a mask containing
the selected chair plus neighbouring objects/background. Reconstruction quality cannot
reach a professional level if the upstream mask is contaminated.

## Changes

- SegFormer remains semantic context only; it never clips the positive object.
- The clicked semantic component is no longer selected by smallest area. The largest
  clicked component is used as the initial semantic prior so tiny fragments do not
  shrink the SAM search envelope.
- Independent semantic components for other furniture, plants, baskets and room
  surfaces become negative evidence for SAM candidate ranking.
- Every SAM multimask/box candidate is scored for click containment, semantic recall,
  SAM confidence, neighbour contamination, and spill outside the positive support.
- Candidates with similar scores prefer cleaner neighbour separation and better
  semantic coverage.
- Disconnected physical-part recovery remains enabled.
- The final component-retention pass that could delete recovered disconnected legs
  was removed; recovered parts are now validated during merge instead.
- GrabCut is explicitly reported as a fallback when SAM is unavailable or produces
  no usable candidate.
- `/select-mask` now returns mask diagnostics including the actual engine,
  fallback status, neighbour overlap, candidate count and recovered physical parts.

## Validation

- `python -m compileall -q server` — passed
- full pytest suite — **71 passed**
- real RTX 3070 Ti/SAM visual benchmark — must still be run on the user's machine.

## Acceptance test

On the living-room armchair benchmark:

1. Click the armchair.
2. The preview mask must contain the complete chair, including plausible legs/arms.
3. The plant and basket must remain outside the mask.
4. The visible floor/rug must remain outside the mask except for deliberately recovered
   contact-shadow pixels in the later reconstruction stage.
5. `/select-mask` diagnostics must identify `Mask Engine V4.1` rather than silently
   reporting a fallback.
