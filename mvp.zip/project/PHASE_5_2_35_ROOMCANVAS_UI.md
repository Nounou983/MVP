# Phase 5.2.35 — RoomCanvas Consumer UI

This build keeps the working Phase 5.2.34 3D/GLB engine and redesigns the workspace to closely follow the supplied RoomCanvas reference.

## UI
- Room is the visual hero and fills the workspace.
- Floating rounded left action rail.
- Bottom furniture discovery tray.
- Contextual floating inspector instead of a permanent right sidebar.
- Clean white retail-style header.
- Technical chrome is minimized.
- Existing furniture catalogue remains functional and its current thumbnails are intentionally retained for this pass.

## 3D
- `THREE.PCFSoftShadowMap` was replaced with `THREE.PCFShadowMap` to remove the Three.js deprecation warning.
- 3D and GLB functionality remains based on the stable 5.2.34 implementation.
