# Phase 5.2.31 — Consumer UX / 3D Fix

## Fixed

1. Removed the old floating white context toolbar from the room. It was a technical editor control that could sit over the furniture and intercept interaction.
2. Hardened the Three.js initialization path. A WebGL initialization failure no longer prevents the rest of the page from loading or silently leaves the 3D controls dead.
3. `Vue 3D` now has an explicit ready-state and failure message.
4. `Importer un modèle 3D` now opens the file picker without requiring a furniture item to be selected first. If nothing is selected, a catalogue furniture item is created as the import target.
5. GLB/GLTF loading now reports clear success/failure status messages.
6. Removed the fragile browser-side WebGL thumbnail-rendering pass from startup. The catalogue thumbnails are now self-contained, richer isometric furniture illustrations generated directly from the furniture definitions, so the catalogue does not depend on a second WebGL context just to display cards.
7. Increased catalogue thumbnail size and improved their presentation.
8. Removed developer-oriented footer hints such as keyboard shortcuts from the main consumer interface.

## User experience

- Select a furniture card to place it.
- Drag the furniture directly on the room.
- Use the simple inspector controls for size/orientation/position.
- Use `Vue 3D` to enter the 3D view.
- Use `＋ Importer un modèle 3D` to replace the selected furniture with a GLB/GLTF model, or import it into a new furniture item if nothing is selected.

## Version

UI/consumer patch: 5.2.31
AI backend remains the Phase 5.2.28 backend.
