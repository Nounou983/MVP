# Phase 6 — Refonte de l'interface

Objectif : passer d'une interface « outil technique » à une interface produit,
au niveau (et au-delà) d'IKEA Kreativ, sans toucher au backend ni au moteur de
suppression d'objet par IA.

## Fichiers modifiés

| Fichier | État |
|---|---|
| `index.html` | réécrit |
| `css/style.css` | réécrit |
| `js/app.js` | réécrit (API publique conservée) |
| `js/furniture-data.js` | réécrit (catalogue enrichi) |
| `js/ui.js` | **nouveau** — couche interface |
| `js/phase3.js` | 1 ligne (couleur des meubles en 3D) |
| `server/main.py` | **intouché** |
| `js/eraser.js` | **intouché** |
| `js/ai.js`, `js/phase3e.js` | **intouchés** |

Les versions d'origine sont conservées dans `_original_backup/`.

## Ce qui a changé

### Structure
Barre d'application (marque, nom de composition, annuler/rétablir, total, actions)
· rail de navigation 5 sections · panneau 360 px à vues multiples · scène sombre
avec la photo en `contain` et ombre portée. La photo est le héros : aucun chrome
ne passe devant elle.

### Système visuel
Jetons de couleur (`--ink`, `--paper`, `--stage`, ambre marque, violet IA),
Schibsted Grotesk, base 14 px (au lieu de 7–9 px), chiffres tabulaires pour les
prix et les cotes. Responsive : sous 760 px le panneau devient une feuille du bas
et le rail passe à l'horizontale.

### Catalogue
15 produits (au lieu de 9) avec famille, prix en DA, nuancier, descriptif.
Recherche, filtres par famille, glisser-déposer vers la photo avec fantôme de
glissement, clic simple = ajout au centre.

### Fiche produit
Nuancier de couleurs, « Remplacer par » (swap façon IKEA), cotes en mètres,
échelle, rotation. La barre contextuelle flottante apparaît sur le meuble
sélectionné : Tourner · Dupliquer · Options · Retirer.

### Sélection
Crochets d'angle ambre style viseur + poignées de rotation et d'échelle +
pastille de cotes, ombre de contact au sol en dégradé radial.

### Historique
Annuler/rétablir sur 60 pas, unifié entre les meubles **et** les retouches IA.
Un simple clic de sélection ne pollue pas l'historique.

### Retouche IA
Parcours en 3 étapes (repérer · confirmer · appliquer) avec bannière, overlay de
traitement et état dans la barre d'application. `showAI()` / `hideAI()`, que
`eraser.js` appelait sans qu'ils existent, sont enfin implémentés.

### Divers
Import photo par bouton ou dépôt de fichier, 3 pièces d'exemple, carte d'analyse
IA + calques, récapitulatif avec total, export intelligent (Phase3E si la 3D est
active, sinon export canvas), toasts, raccourcis (E, 1, 2, C, Suppr, Échap, ?,
Ctrl+Z / Ctrl+Maj+Z).

## Bugs corrigés

1. `window.CigogneUI.showAI()` / `hideAI()` étaient appelés par `eraser.js` mais
   n'existaient nulle part → aucun retour visuel pendant le travail de l'IA.
2. `resize()` n'était jamais rebranché sur `window.resize` → canvas déformé au
   redimensionnement. Remplacé par un `ResizeObserver`.
3. Les bascules de calques étaient des `<button>` enveloppant un `<input hidden>`
   → elles ne basculaient jamais.
4. `#status`, qui portait tous les retours utilisateur, était caché hors écran.
5. En vue 3D les meubles étaient rendus deux fois (sprites 2D + volumes 3D).
6. Le canvas 3D invisible volait les clics après usage de la gomme
   (`pointer-events:auto` posé en inline par `eraser.js`).
7. La couleur choisie dans le nuancier n'était pas reprise en 3D.

## Bug connu, contourné et non corrigé à la source

`js/eraser.js` appelle `pushHistory()` **après** `loadRoom()`, donc son undo natif
recharge l'image déjà retouchée. Le fichier étant hors périmètre, `ui.js` mémorise
l'image d'avant retouche et intercepte `Ctrl+Z` / `Ctrl+Y` en phase de capture
avec `stopPropagation()`. L'annulation d'une retouche IA fonctionne donc
correctement depuis l'interface. Si un jour `eraser.js` devient modifiable, la
vraie correction tient en une ligne : déplacer `pushHistory()` avant `loadRoom()`.

## Lancement

```bash
cd server && uvicorn main:app --reload --port 8000
# puis, à la racine du projet :
python -m http.server 5500
```
