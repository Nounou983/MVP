# Phase 10.2 — Assistant noun/anchor parsing fix

## Bug fixed
The command `Ajoute deux lampes de chaque côté du canapé` was interpreted as a sofa request because the generic noun detector found `canapé` before understanding that it was the spatial anchor.

## Fix
Composition commands now identify the **first explicit furniture noun after the action verb** as the requested product type. Later furniture nouns are treated as spatial/context anchors.

Examples:
- `Ajoute deux lampes de chaque côté du canapé` → 2 lamps; sofa is the anchor.
- `Ajoute une table basse devant le canapé` → 1 coffee table; sofa is the anchor.
- `Ajoute un canapé moderne beige` → sofa.
- `Ajoute deux chaises autour de la table` → 2 chairs; table is the anchor.

The existing multi-object placement and catalog search remain unchanged.
