# Mask Engine V4

Mask Engine V4 is the click-first furniture-selection pipeline used by `/select-mask`.

## Design goals

- The user's click is the primary constraint.
- SegFormer is optional context, never a hard object boundary.
- SAM is queried through click-only, semantic-context, and independent multi-scale box prompts.
- A partially detected semantic component cannot shrink the SAM search envelope to the fragment.
- Candidate selection is relative/click-first rather than dependent on a brittle absolute score threshold.
- Boundary probes run independent positive-point SAM queries to recover detached legs, arms, rails and feet when geometrically plausible.
- Final morphology intentionally avoids opening/erosion that would erase thin furniture structures.
- GrabCut remains an explicit fallback only when SAM is unavailable or produces no usable candidate.

## Expected logs

`Mask Engine V4: method=..., candidates=..., area_ratio=..., confidence=..., score=...`

If SAM is unavailable, the backend reports a V4 GrabCut fallback warning instead of silently presenting it as a SAM result.


## V4.1 repair

V4.1 adds semantic neighbour protection to candidate scoring. SegFormer components other than the clicked component are negative evidence only; they are not used as hard positive boundaries. The selection endpoint reports the actual engine/fallback and mask diagnostics. Physical-part recovery is preserved without a second post-merge component pruning pass that could delete disconnected legs.
