# Phase 8.1 — AI Selection Studio

## What changed

- Multi-object selection is now persistent: clicking a second object adds it instead of replacing the first selection.
- One confirmation sends the union of all enabled masks to `/inpaint`.
- New floating AI Selection Studio shows detected objects, confidence indicators, enable/disable controls, reset, preview, and a single multi-object removal action.
- Automatic related-object discovery is returned by `/select-mask` using SegFormer semantic components. Related suggestions are visible and removable before confirmation.
- SAM remains responsible for the clicked object's precise silhouette; SegFormer is used as semantic/context evidence.
- If ADE20K misses the clicked object, the selection path no longer immediately fails: SAM receives a point-only prompt, with a compact GrabCut prior as fallback.
- Undo now captures the original image **before** AI reconstruction, fixing the previous history ordering bug.

## Selection flow

1. Activate **Retouche IA**.
2. Click object A → precise SAM mask.
3. Related semantic objects can be added automatically.
4. Click object B/C/... → previous selections remain.
5. Uncheck anything you do not want removed.
6. Confirm once → union mask → one reconstruction.

## Validation

- All JavaScript files pass `node --check`.
- Python AI/API modules pass `py_compile`.
- Existing backend suite: **47 passed**.
- No cloud GPU result is claimed from this package; remote validation still requires an actual cloud runtime/account.
