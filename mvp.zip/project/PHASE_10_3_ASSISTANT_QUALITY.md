# Phase 10.3 — Assistant reliability upgrade

## Scope
This pass improves the catalogue assistant only. The AI removal, mask detection, RORem and LaMa pipelines are intentionally untouched.

## Changes
- Robust noun parsing with spatial-anchor awareness (`lampes ... du canapé` no longer resolves to the sofa).
- Quantity parsing for numeric and French number words.
- Explicit handling of `de chaque côté` for the requested lamp pair.
- Multi-product commands split into independent composition clauses, e.g. canapé + table basse in one command.
- Assistant verifies the number of objects actually created before reporting success.
- Failed/partial mutations are reported as such instead of producing a false success message.
- Assistant result cards also verify that the catalogue action really changed the composition.
- Existing `AppActions.addItemsBatch()` remains backward-compatible; an optional history flag allows one natural-language multi-action command to share one undo snapshot.
- Existing placement assistance remains the placement authority after coordinates are proposed by the assistant.

## Intentionally unchanged
- `js/eraser.js`
- `server/main.py`
- RORem / LaMa
- mask detection / SAM pipeline
- 3D rendering
- project storage backend
