# Phase 5.2.37 — Spatial UI / 3D-Preserving Frontend

## Purpose
Premium 2026 consumer-facing spatial interface redesign while preserving the working Phase 5.2.34 3D / GLB JavaScript implementation.

## Structural contract
- `#app-container`: relative 100vw × 100vh viewport.
- `#viewport.stage-wrap`: absolute full-screen viewport containing the original `#stage` and `#threeStage` canvases.
- `#ui-layer`: absolute full-screen transparent interaction layer above the viewport.
- UI children are pointer-enabled; viewport remains the rendering surface.

## UI changes
- One unified floating top navigation bar.
- Soft, non-boxy active tool state.
- Floating glass product catalog tray with shopping-style cards.
- Product thumbnails use real photo URLs with local SVG fallback; existing Phase 3D thumbnail rendering remains available.
- Contextual object menu and contextual inspector.
- Mobile bottom-sheet behavior.
- Removed the old yellow floor-profile / debug visual from the frontend layer.

## 3D / GLB
- `js/phase3.js` is intentionally not rewritten in this phase.
- Existing `stage-wrap` contract is preserved by giving `#viewport` that class.
- The top-level boot remains dynamic and waits for the existing Phase 3 module.
