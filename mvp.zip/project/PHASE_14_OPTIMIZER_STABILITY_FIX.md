# Phase 14 — Optimizer Stability Fix

## Scope
Only the existing Spatial Intelligence optimizer was changed. Mask detection, AI removal, RORem, LaMa, reconstruction, assistant parsing, catalog, and rendering were not modified.

## Problem fixed
The previous optimizer moved every item 34% toward a generic semantic target. For a correctly placed sofa, that target could be the centre of a detected wall, producing a large visible jump when the user clicked **Optimiser la composition**.

## New behavior
- Treats optimization as **refinement**, not repositioning from scratch.
- Scores the current position first.
- Uses the semantic target only as a gentle 10% correction vector.
- Caps a normal correction to 3% of the room image (max 48 px).
- Requires a meaningful score improvement before moving an already-valid item.
- Repairs floor/collision/opening violations with a lower acceptance threshold.
- Keeps already-correct sofas, beds, tables, etc. visually stable.

## Regression protection
A backup of the pre-Phase-14 optimizer is kept as `js/spatial-intelligence.js.bak_optimizer_phase14`.
