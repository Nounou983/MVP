# Mask Engine V4 — SAM compatibility fix

## What was fixed

The previous Mask Engine V4 was not actually using SAM during selection on the affected environment. The terminal showed repeated errors such as:

`SAM prompt failed: The size of tensor a (...) must match the size of tensor b (...) at non-singleton dimension 2`

That caused every `/select-mask` request to fall through to GrabCut, which explains the oversized selections and missing thin furniture parts seen in testing.

### Changes

- Corrected Hugging Face Transformers 5.x SAM point-prompt nesting:
  - points: `[image][object][point][x,y]`
  - labels: `[image][object][point]`
- Separated SAM point prompts and box prompts into independent inference calls. This avoids processor-shape ambiguity when both are supplied together.
- Kept SAM multimask output enabled and normalized the different output tensor shapes seen across Transformers 5.x releases.
- Preserved the existing click-first scoring and physical-part repair logic.
- No changes were made to the frontend duplicate-object naming behavior because that was explicitly identified as expected behavior when selecting a bed plus its pillow.
- Added regression tests for the SAM prompt shapes.

## Validation

`pytest -q server/tests` => **69 passed**

The test suite is CPU-only and does not prove the downloaded SAM checkpoint's GPU inference quality. The next real test is the user's RTX 3070 Ti machine: `/select-mask` should no longer print `SAM prompt failed` or `Mask Engine V4 failed, using GrabCut fallback` for normal clicks.
