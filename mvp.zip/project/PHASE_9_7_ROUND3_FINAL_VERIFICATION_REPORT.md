# La Cigogne D'Ailleurs — Phase 9.7 Round 3 Verification / Fix Package

## Executive conclusion

### Case B headline: why did `furniture_penalty=0.4660` pass?

The current source does **not** use OR-compensation.

The RORem direct-accept path calls `_candidate_passes_removal_gate()` and that function is a strict conjunction:

```text
passed =
    change >= noop_target_change
AND seam <= max_seam
AND furniture_penalty <= max_furniture_penalty
AND residual_structure <= max_residual_structure
AND texture_ratio >= min_texture_ratio
AND surface_consistency >= min_surface_consistency
```

Source: `server/main.py:1909-1917`.

Before this round the authoritative value was:

```text
max_furniture_penalty = 0.60
```

Therefore Case B's `furniture_penalty=0.4660` **was under the threshold and passed** because `0.4660 <= 0.60`. Its excellent `seam=4.94` and `texture_ratio=1.59` did not compensate through OR logic; they simply satisfied two other AND clauses.

The authoritative threshold is now tightened to:

```text
max_furniture_penalty = 0.45
```

Source: `server/main.py:33-38`.

This is deliberately a conservative, evidence-grounded boundary: it is the smallest simple change needed to force the observed real bad case `0.4660` to fail, while also rejecting the earlier real `0.6774` case. It is **not** claimed to be a statistically calibrated optimum.

### Important limitation

The exact raw RORem image for Case B was not included in the supplied project ZIP. Therefore this round can prove the **gate defect** and fix it, but cannot honestly prove whether the visible ghosting originates inside raw RORem or after compositing.

The compositor itself is source-level deterministic: `server/main.py:3000-3024` copies generated pixels at full opacity inside the binary mask and restores original pixels outside it. The synthetic regression remains green. A fresh RTX artifact trace is still required to prove the real Case B raw-vs-final boundary.

---

# A1-A10 verification matrix

| ID | Acceptance item | Status | Evidence |
|---|---|---|---|
| A1 | Current RORem direct gate boolean + exact threshold | **PASS** | `server/main.py:1909-1917`; threshold at `33-38` |
| A2 | Case A/B/C reusable artifact trace | **PARTIAL — RTX required** | reusable multi-case tracer + 3-case manifest included; exact neural artifacts absent |
| A3 | Case B per-component scoring | **NOT VERIFIED — RTX artifact required** | exact submitted mask/raw candidate absent |
| A4 | Fix selected according to evidence | **PASS for gate defect; visual root cause pending RTX** | `0.4660` now fails; compositor remains unchanged |
| A5 | Texture-ratio context question | **NOT SAFE TO NORMALIZE YET** | real logs show large scene-dependent spread; raw images needed for perceptual diagnosis |
| A6 | B2 glossy-blob + low-change tests | **PASS** | current suite: 85 passed; four relevant regression tests pass |
| A7 | Frontend 422 handling | **PASS by source inspection** | `js/eraser.js:247-275` |
| A8 | `/inpaint-status` authority + threshold consistency | **PASS by source/tests** | same `REMOVAL_GATE_THRESHOLDS` mapping is used |
| A9 | Selection/network-boundary diagnostics | **IMPLEMENTED; fresh browser trace required** | client now sends selection keys; server logs union-mask component count |
| A10 | Ready-to-run package | **PASS** | ZIP includes source fix, tests, tracer, manifest, diagnostics and report |

---

# 1. Case A — 12.26% bed/armchair, HTTP 422

Runtime metadata from the supplied RTX trace:

```text
mask = 12.26%
image = 1408 × 768
bbox = (578,353)-(1172,736)

RORem selected seed=2026
furniture_penalty = 0.7289
seam = 31.32
texture_ratio = 0.15
surface_consistency = 0.827
passed_gate = false

surface ensemble:
accepted = 1
substantial = 2
=> rejected

LaMa:
seam = 59.78
furniture_penalty = 0.0893
texture_ratio = 0.23
surface_consistency = 0.900
passed_gate = false

HTTP /inpaint = 422
```

This is consistent with the honest-failure contract. No failed candidate is served in normal mode.

The supplied UI screenshot visually shows two selected physical objects (bed + armchair), but the exact binary network mask was not captured. Therefore the screenshot is retained only as reference evidence, not treated as an exact mask artifact.

---

# 2. Case B — 3.72% nightstand + office chair, HTTP 200

Supplied runtime metadata:

```text
mask = 3.72%
image = 1536 × 1024
bbox = (202,432)-(1408,824)

RORem selected seed=11037
seam = 4.94
furniture_penalty = 0.4660
target_change = 0.266
residual_structure = 0.172
texture_ratio = 1.59
surface_consistency = 0.885
passed_gate = true
HTTP /inpaint = 200
```

The supplied final screenshot visibly contains residual/ghosted structure around the nightstand/lamp and office-chair/desk regions.

### Why the acceptance happened

With the previous threshold:

```text
0.4660 <= 0.60
```

so the AND gate returned true.

With the new threshold:

```text
0.4660 <= 0.45  -> FALSE
```

therefore the complete conjunction is false.

A permanent regression test was added for this exact observed metric tuple.

---

# 3. Case C — 2.19% surface-aware ensemble

The supplied RTX log contains this separate path:

```text
mask = 2.19%
bbox = (57,419)-(338,637)
image = 1408 × 768

RORem selected:
seam = 9.35
fp = 0.0314
change = 0.394
texture_ratio = 0.23
passed_gate = false

Surface partitions:
wall:
    seam = 34.50
    fp = 0.506
    change = 0.370
    texture = 0.83
    residual = 0.032

floor:
    seam = 28.87
    fp = 0.061
    change = 0.376
    texture = 0.14

floor LaMa:
    seam = 24.46
    fp = 0.464
    change = 0.387
    texture = 0.28

Surface ensemble:
accepted = 2
substantial = 2
full metrics:
    seam = 23.94
    fp = 0.477
    change = 0.384
    residual = 0.000
    texture = 0.53
    surface = 0.842

Phase9.7 surface-aware ensemble PASSED removal gate
HTTP /inpaint = 200
```

Under the old global `0.60` furniture ceiling, the final full-metrics `fp=0.477` passed.

Under the new `0.45` ceiling:

```text
0.477 <= 0.45 -> FALSE
```

so the current source will no longer direct-accept that final surface-aware candidate either.

This is intentional: it prevents another observed high-furniture-penalty candidate from bypassing the same quality contract through a different acceptance path. A fresh RTX run must confirm whether this rejects a visually bad surface reconstruction or whether the threshold is unnecessarily conservative for that path.

---

# 4. Artifact trace — what is actually available

The project now contains:

```text
diagnostics/
  phase97_round3_cases.json

  phase97_round3_runtime/
    case_a_bed_armchair/
    case_b_nightstand_chair/
    case_c_surface_ensemble/
```

Each case has the required artifact names:

```text
mask_submitted.png
rorem_raw_selected.png
lama_raw.png
surface_raw.png
composited_final.png
alpha_map.png
diagnostic_report.json
```

However, because the supplied bundle did not contain the exact RTX runtime binaries, missing neural artifacts are explicitly watermarked and marked `not_captured`. They are **not** presented as model outputs.

The A/B folders additionally contain screenshot-only reference images:

```text
ui_selection_reference.png
final_screenshot_reference.png
```

These are explicitly labelled reference-only.

This is preferable to fabricating a raw RORem image from a final screenshot.

---

# 5. Reusable diagnostic implementation

`server/tools/phase97_artifact_trace.py` has been upgraded from the previous single-case tool to a manifest-driven multi-case diagnostic.

It can:

- ingest the exact submitted binary mask;
- calculate dimensions, area ratio, bbox and connected components;
- save/validate alpha ownership;
- compare original vs final outside the mask;
- compare raw candidate vs final inside the mask;
- report exact max differences;
- compute per-connected-component production quality metrics when the project scorer is available;
- never fabricate missing neural artifacts.

Run it with:

```bash
python server/tools/phase97_artifact_trace.py ^
  --manifest diagnostics/phase97_round3_cases.json ^
  --output-dir diagnostics/phase97_round3_runtime
```

---

# 6. RTX capture instrumentation added

The product backend now has an opt-in capture boundary controlled by:

```text
CIGOGNE_PHASE97_CAPTURE_DIR=<directory>
```

When enabled, the real `/inpaint` execution automatically captures:

```text
original.png
mask_submitted.png

rorem_raw_seed2026.png
rorem_raw_seed7319.png
rorem_raw_seed11037.png
rorem_raw_seed17041.png
rorem_raw_seed24019.png   # when the large-object configuration uses it

rorem_raw_selected.png
lama_raw.png
surface_raw.png
composited_final.png
```

For a normal failed 422 case, `composited_final.png` is still captured as a **diagnostic-only** composite but is never returned to the browser.

This closes the previous artifact-capture gap without weakening the production quality gate.

---

# 7. Real compositing diagnosis

### What is proven now

`_composite_inside_mask()` uses a binary ownership mask:

```text
a = binary mask
out = original * (1-a) + generated * a
outside mask -> original
inside mask  -> generated
```

Source: `server/main.py:2999-3024`.

There is no Gaussian/feather alpha at this final boundary.

The permanent synthetic invariant remains:

```text
outside-mask max difference = 0
inside-mask output == generated candidate
```

The source therefore does not currently contain the previous partial-opacity-inside-mask implementation.

### What is NOT proven

The real Case B raw RORem output is missing.

Therefore:

```text
RAW RORem already ghosted?
    -> gate/generation problem

RAW RORem clean, final ghosted?
    -> downstream compositing problem
```

cannot yet be decided from the supplied files.

The current round therefore does **not** falsely claim that the compositor is the cause or that RORem is the sole visual cause.

---

# 8. Case B per-component scoring

The requested per-component calculation requires:

1. exact submitted Case B mask;
2. exact raw selected RORem image;
3. original Case B image.

Those three artifacts are not present in the bundle.

The UI screenshot shows two intended selected regions (nightstand/lamp and chair/desk), but screenshot geometry is not the network mask.

Therefore the report deliberately does not invent per-component furniture penalties.

The reusable tracer now supports this calculation automatically once the exact RTX artifacts are supplied.

Recommendation: **do not add per-component product gating yet.**

First capture one exact Case B run and determine whether:
- one component is clean and one is bad, or
- both are mediocre.

If the latter is confirmed, the current scalar gate is the appropriate fix. If the former is confirmed, per-component gating becomes justified.

---

# 9. Texture-ratio question

The supplied RTX logs show a large scene-dependent spread.

Case A:

```text
outside_var ≈ 1372.8
texture_ratio ≈ 0.119–0.150 across RORem
```

Case B:

```text
outside_var ≈ 325–386
texture_ratio ≈ 1.4–1.6
```

Case C also contains partitions with ratios from approximately `0.05` to `0.83`.

This is strong evidence that the metric is highly dependent on the visual context.

However, the raw candidate images are still required to decide whether the low ratio in Case A corresponds to genuinely poor/flat reconstruction or is mainly an artifact of the room's ambient texture density.

Therefore:

**Do not normalize or relax `min_texture_ratio=0.35` yet.**

The next RTX trace should capture raw images and calculate the metric both against the current local ring and a normalized ambient-texture baseline. That is the correct evidence needed before changing this threshold.

---

# 10. B2 adversarial tests

The current project suite was executed after the changes:

```text
85 passed in 9.93s
node --check js/eraser.js       PASS
python -m py_compile ...        PASS
```

Relevant B2 results:

### Glossy blob

Historical old behavior:

```text
surface_consistency = 0.251401
old gate = TRUE
```

Current behavior:

```text
minimum surface consistency = 0.60
current gate = FALSE
```

The furniture penalty is `0.000`, so the rejection is coming from the surface-consistency guard rather than the furniture threshold.

### Reasonable low-change case

```text
target_change = 0.163
seam = 5.24
furniture_penalty = 0
residual = 0
texture_ratio = 0.80
surface_consistency = 0.95

current gate = TRUE
```

This confirms the previous blanket `target_change >= 0.34` restriction is no longer present.

### Real 0.6774 case

```text
old 0.70 ceiling -> TRUE
previous 0.60 ceiling -> FALSE
current 0.45 ceiling -> FALSE
```

### Real 0.4660 Case B

```text
previous 0.60 ceiling -> TRUE
current 0.45 ceiling -> FALSE
```

This exact runtime value now has a permanent regression test.

---

# 11. Frontend HTTP 422 contract

`js/eraser.js:247-275` explicitly handles HTTP 422.

It:

1. parses the JSON payload;
2. recognizes `status===422`;
3. displays an explicit user-facing message;
4. never calls `loadRoom()` on the 422 branch;
5. therefore never replaces the canvas with an unconfirmed image;
6. removes the history snapshot;
7. hides the AI status UI;
8. finally resets `busy=false` and re-enables the button.

The original `state.roomImage` is not replaced on this path.

Thus the 422 behavior is honest and non-destructive.

---

# 12. Selection/network boundary

The frontend now sends:

```text
selection_keys = JSON.stringify(active.map(s => s.key))
```

Source: `js/eraser.js:243-247`.

The union builder includes only:

```text
if (!item.enabled) continue
```

Source: `js/eraser.js:101-104`.

Related suggestions are explicitly inserted disabled:

```text
suggestion.enabled = false
```

Source: `js/eraser.js:132-142`.

The backend now logs:

```text
Phase9.7 selection boundary:
keys=[...]
union_mask_components=N
area_ratio=...
```

This makes the exact client selection and the exact submitted union-mask component count visible at the network boundary on the next RTX run.

A fresh browser trace is still required to prove the specific second "Bed" entry is absent from that particular submitted mask.

---

# 13. What changed in this package

### Product code

1. `max_furniture_penalty`: `0.60 -> 0.45`.
2. Added permanent Case-B `fp=0.4660` regression.
3. Added explicit conjunctive-gate regression.
4. Added opt-in exact RTX artifact capture.
5. Added client selection-key submission.
6. Added server union-mask component logging.

### Diagnostics

1. Multi-case artifact tracer.
2. Three-case manifest.
3. Three diagnostic directories.
4. Reference screenshots clearly labelled as non-runtime artifacts.
5. B2 numbers updated for the new threshold.

### Out of scope

Still unchanged:

- RORem seed/ensemble redesign
- SAM replacement
- 512×512 working-resolution architecture

---

# 14. Fresh RTX verification still required

This package is **not** claiming the visual quality problem is solved.

The following require one fresh RTX run:

- exact Case B mask;
- exact Case B raw RORem selected output;
- exact Case B final composite;
- real alpha/invariant check;
- Case B component-by-component scores;
- Case C behavior under the tightened threshold;
- browser selection keys + server union-mask component count;
- visual confirmation that `0.4660` no longer produces an HTTP 200.

The capture instrumentation is now in the backend specifically so this trace is reproducible rather than reconstructed from screenshots.

---

## Final status

**Gate defect:** fixed in source.

**Case B `0.4660` acceptance:** fixed — it now fails the furniture threshold.

**B2:** verified — 85/85 suite pass.

**422 frontend:** verified by source inspection.

**Exact three-case neural artifact trace:** still requires the user's RTX runtime; this package deliberately does not fake those artifacts.

**Ready-to-run package:** this ZIP.
