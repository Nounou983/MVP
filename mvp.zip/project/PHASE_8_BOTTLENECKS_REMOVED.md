# Phase 8 — Bottleneck Removal

## Completed in this release

### 1. Real furniture assets
13 of the 15 catalog products now use real, textured CC0 furniture/lighting/plant assets from Poly Haven for thumbnails, product previews and 3D models. The two remaining rug entries keep the existing fallback because a rug-specific CC0 3D asset was not selected in this pass.

Every upgraded product records:
- provider
- source asset ID
- source URL
- CC0 license URL
- preview image
- model URL
- `is_placeholder: false`

### 2. Visual quality
- Product cards now use real preview photography/render imagery instead of vector sprites when available.
- Product source/provenance is visible in the catalog data path.
- Existing high-resolution Phase 3E render path is preserved.
- Existing color matching, contact shadows, occlusion, perspective and 3D-resolution rendering remain intact.

### 3. Cloud/GPU path
A Hugging Face ZeroGPU validation adapter is included at:
`deploy/huggingface-zerogpu/`

It reuses the existing `server/main.py` inference implementation instead of creating a second model implementation. It exposes room analysis, SAM selection and remove-only AI through a Gradio Space.

### 4. Deployment configuration
- `deployment-config.js` was added as the single public deployment override point.
- `js/config.js` remains the source of runtime defaults.
- Static frontend deployment instructions are included.
- ZeroGPU deployment instructions are included.
- Existing API/worker architecture is preserved.

## What cannot be honestly marked as remotely validated here

This build environment cannot log into the user's Hugging Face account or allocate a remote ZeroGPU instance. Therefore the cloud GPU execution itself is prepared but not falsely marked as tested. The final cloud smoke test must be run once the Space is created.

Likewise, the current real assets are CC0 technical/demo assets, not a licensed retailer's proprietary product catalog. Replace them with authorized manufacturer assets when the commercial catalog is finalized.
